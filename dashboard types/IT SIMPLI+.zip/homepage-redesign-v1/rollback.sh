#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 /home/pi5/homepage-backup-YYYYMMDD-HHMMSS"
  exit 1
fi

BACKUP="$1"
LAN="/srv/docker/configs/homepage"
TS="/srv/docker/configs/homepage-tailscale"

test -d "$BACKUP/homepage"
test -d "$BACKUP/homepage-tailscale"

sudo cp -a "$BACKUP/homepage/." "$LAN/"
sudo cp -a "$BACKUP/homepage-tailscale/." "$TS/"
docker restart pi-homepage-homepage-1 pi-homepage-tailscale >/dev/null
echo "ROLLBACK DONE"
