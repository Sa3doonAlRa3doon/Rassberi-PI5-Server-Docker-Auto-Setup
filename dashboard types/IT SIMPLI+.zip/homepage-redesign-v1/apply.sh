#!/usr/bin/env bash
set -euo pipefail

LAN="/srv/docker/configs/homepage"
TS="/srv/docker/configs/homepage-tailscale"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/home/pi5/homepage-backup-$STAMP"

echo "[1/5] Backing up current Homepage configs to $BACKUP"
sudo mkdir -p "$BACKUP/homepage" "$BACKUP/homepage-tailscale"
sudo cp -a "$LAN/." "$BACKUP/homepage/"
sudo cp -a "$TS/." "$BACKUP/homepage-tailscale/"

echo "[2/5] Installing LAN config"
sudo cp -f homepage/settings.yaml homepage/widgets.yaml homepage/services.yaml homepage/custom.css homepage/custom.js homepage/bookmarks.yaml "$LAN/"

echo "[3/5] Installing Tailscale config"
sudo cp -f homepage-tailscale/settings.yaml homepage-tailscale/widgets.yaml homepage-tailscale/services.yaml homepage-tailscale/custom.css homepage-tailscale/custom.js homepage-tailscale/bookmarks.yaml "$TS/"

echo "[4/5] Fixing ownership/read permissions"
sudo chown -R 1000:1000 "$LAN" "$TS"
sudo find "$LAN" "$TS" -type d -exec chmod 750 {} \;
sudo find "$LAN" "$TS" -type f -exec chmod 640 {} \;

echo "[5/5] Restarting both Homepage containers"
docker restart pi-homepage-homepage-1 pi-homepage-tailscale >/dev/null

echo
echo "DONE"
echo "LAN:       http://192.168.4.123:3000"
echo "Tailscale: http://100.87.69.98:3010"
echo "Backup:    $BACKUP"
echo
echo "Check:"
docker ps --filter name=pi-homepage-homepage-1 --filter name=pi-homepage-tailscale \
  --format 'table {{.Names}}\t{{.Status}}'
