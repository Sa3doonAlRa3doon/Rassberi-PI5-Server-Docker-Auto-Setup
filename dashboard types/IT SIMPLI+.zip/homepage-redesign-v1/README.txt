Homepage redesign v1
====================

This package changes ONLY Homepage configuration files.
It does NOT change your Docker Compose files, ports, storage-metrics service, or other containers.

Folders:
- homepage/             -> /srv/docker/configs/homepage
- homepage-tailscale/   -> /srv/docker/configs/homepage-tailscale

Main changes:
- Layout names now match services.yaml exactly.
- Heavy custom JavaScript is replaced by an intentionally empty file.
- CSS is reduced to a small lightweight UI layer.
- Native datetime + search widgets are enabled.
- All known services are preserved.
- LAN URLs use 192.168.4.123.
- Tailscale URLs use 100.87.69.98.
- Existing Actual Budget Tailscale HTTPS URL is preserved.
- Existing OnlyOffice :8081 URL is preserved exactly as requested.

Apply on Pi:
1. Unzip/copy this folder to the Pi.
2. cd into homepage-redesign-v1
3. chmod +x apply.sh rollback.sh
4. ./apply.sh

The apply script creates a timestamped backup before changing anything.

After applying, Homepage settings changes may require using Homepage's refresh control
or a hard browser refresh (Ctrl+F5).

This package has been syntax-checked as YAML locally.
Runtime service reachability still depends on the Pi and containers themselves.
